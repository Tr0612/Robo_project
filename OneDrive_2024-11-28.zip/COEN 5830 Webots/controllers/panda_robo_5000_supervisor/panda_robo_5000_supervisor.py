#Write the supervisor code here to control the panda robot
